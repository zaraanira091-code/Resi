// Vercel Serverless Function: membaca nomor AWB dari foto form retur lewat Claude API.
// Butuh Environment Variable ANTHROPIC_API_KEY di pengaturan project Vercel.
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "method_not_allowed" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ error: "ANTHROPIC_API_KEY belum diatur" });

  let body = req.body;
  if (typeof body === "string") { try { body = JSON.parse(body); } catch { body = {}; } }
  const { image, prompt } = body || {};
  if (!image || typeof image !== "string") return res.status(400).json({ error: "gambar_kosong" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-5-5",
        max_tokens: 1500,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } },
            { type: "text", text: String(prompt || "Tulis semua nomor AWB (2 huruf + 10 angka) pada gambar, satu per baris.").slice(0, 2000) },
          ],
        }],
      }),
    });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ error: (j.error && j.error.message) || "api_error" });
    const text = (j.content || []).map(c => (c.type === "text" ? c.text : "")).join("\n");
    return res.status(200).json({ text });
  } catch (e) {
    return res.status(500).json({ error: "gagal_menghubungi_api" });
  }
}
